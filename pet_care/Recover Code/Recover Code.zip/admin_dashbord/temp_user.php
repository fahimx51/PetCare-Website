<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temporary Users</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('../admin_dashbord/admin_img/admin_background.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            color: #444;
        }

        h2 {
            color: #333;
            text-align: center;
            padding-top: 20px;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .table-container {
            width: 90%;
            margin: 0 auto;
            overflow-x: auto; /* Add scroll for small screens */
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 50px;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .user-table th, .user-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .user-table th {
            background-color: #f7f7f7;
            color: #333;
            font-weight: bold;
        }

        .user-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .user-table tr:hover {
            background-color: #e0e0e0;
        }

        .profile-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ddd;
        }

        .no-img {
            font-style: italic;
            color: #999;
        }

        .btn {
            display: inline-block;
            padding: 8px 16px;
            margin-right: 5px;
            margin-bottom: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .btn-delete {
            background-color: #f44336;
            color: white;
        }

        .btn-approve {
            background-color: #4CAF50;
            color: white;
        }

        .btn:hover {
            opacity: 0.8;
        }

        .btn-delete:hover {
            background-color: #d32f2f;
        }

        .btn-approve:hover {
            background-color: #388e3c;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .user-table, .user-table th, .user-table td {
                font-size: 14px;
            }

            .table-container {
                width: 95%;
            }

            .btn {
                padding: 6px 12px;
            }
        }

        /* Add some spacing at the bottom */
        body {
            margin-bottom: 50px;
        }
    </style>
</head>
<body>
<?php
// Include database connection file
include_once 'config.php';

// Fetch all temporary users from the 'temp_users' table
$sql_temp_users = "SELECT * FROM temp_users";
$result_temp_users = mysqli_query($conn, $sql_temp_users);

// Display temporary users in a table with CRUD buttons
echo "<h2>Temporary Users</h2>";
if (mysqli_num_rows($result_temp_users) > 0) {
    echo "<div class='table-container'>";
    echo "<table class='user-table'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Password</th><th>Confirm Password</th><th>Address</th><th>Profile Picture</th><th>Verification Code</th><th>Created At</th><th>Actions</th></tr>";
    while ($row = mysqli_fetch_assoc($result_temp_users)) {
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td>".$row['password']."</td>";
        echo "<td>".$row['confirm_pass']."</td>";
        echo "<td>".$row['address']."</td>";
        echo "<td>";
        // Check if user has a profile image
        $profileImagePath = $row['profile_picture'];
        if (!empty($profileImagePath) && file_exists($profileImagePath)) {
            echo "<img src='$profileImagePath' class='profile-img' alt='Profile Image'>";
        } else {
            echo "<div class='no-img'>No Image</div>";
        }
        echo "</td>";
        echo "<td>".$row['verification_code']."</td>";
        echo "<td>".$row['created_at']."</td>";
        echo "<td>";
        // Add buttons to delete and approve temporary users
        echo "<a href='delete_temp_user.php?id=".$row['id']."' class='btn btn-delete'>Delete</a>";
        echo "<a href='approve_temp_user.php?id=".$row['id']."' class='btn btn-approve'>Approve</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
} else {
    echo "<p style='text-align: center; color: #777; font-style: italic;'>No temporary users found.</p>";
}
?>
</body>
</html>
