<?php
include_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $appointmentId = $_POST['id'];

    $sql_select_appointment = "SELECT * FROM petvet1 WHERE id = $appointmentId";
    $result_select_appointment = mysqli_query($conn, $sql_select_appointment);

    if (mysqli_num_rows($result_select_appointment) > 0) {
        $appointmentData = mysqli_fetch_assoc($result_select_appointment);

        $insertSql = "INSERT INTO approved_appointments (username, appointmentDate, appointmentTime, numberOfPets, phoneNumber, petType) 
                      VALUES ('{$appointmentData['username']}', '{$appointmentData['appointmentDate']}', '{$appointmentData['appointmentTime']}', '{$appointmentData['numberOfPets']}', '{$appointmentData['phoneNumber']}', '{$appointmentData['petType']}')";
        if (mysqli_query($conn, $insertSql)) {
            $deleteSql = "DELETE FROM petvet1 WHERE id = $appointmentId";
            if (mysqli_query($conn, $deleteSql)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to delete appointment']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to insert appointment into approved_appointments']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Appointment not found']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
